package Backend.ClinicaOdontologica.repository;

import Backend.ClinicaOdontologica.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno,Long> {
}