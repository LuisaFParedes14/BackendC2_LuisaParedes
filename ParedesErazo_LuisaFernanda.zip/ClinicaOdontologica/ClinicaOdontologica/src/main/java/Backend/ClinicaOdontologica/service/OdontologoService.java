package Backend.ClinicaOdontologica.service;

import Backend.ClinicaOdontologica.entity.Odontologo;
import Backend.ClinicaOdontologica.repository.OdontologoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OdontologoService {
    @Autowired
    private static OdontologoRepository odontologoRepository;

    public Odontologo registrarOdontologo(Odontologo odontologo){
        return odontologoRepository.save(odontologo);
    }
    public List<Odontologo> listarTodos(){
        return odontologoRepository.findAll();
    }
    public static Optional<Odontologo> buscarPorID(Long id){
        return   odontologoRepository.findById(id);
    }

    public boolean eliminarOdontologo(Long id) {
        return false;
    }

    public Odontologo registrarOdontologo(Long id, Odontologo odontologo) {
        return odontologo;
    }
}