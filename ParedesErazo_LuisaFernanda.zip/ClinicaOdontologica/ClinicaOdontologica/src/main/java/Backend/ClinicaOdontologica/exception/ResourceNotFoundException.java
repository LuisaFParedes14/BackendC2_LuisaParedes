package Backend.ClinicaOdontologica.exception;

public class ResourceNotFoundException extends Exception  {
    //vendria la exception y yo la deberia poder procesar de la mejor manera posible,

    public ResourceNotFoundException(String message) {
        super(message);
    }
}