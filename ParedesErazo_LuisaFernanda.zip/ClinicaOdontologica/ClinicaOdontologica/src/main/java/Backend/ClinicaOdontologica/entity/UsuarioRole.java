package Backend.ClinicaOdontologica.entity;

public enum UsuarioRole {
    ROLE_USER, ROLE_ADMIN
}